
<br>

<div align="center">
  <a href="https://github.com/tedbrakob/teamwork-show-full-task-title">
    <img src="images/icon.png" alt="Logo" width="80" height="80">
  </a>

  <h3 align="center">Teamwork Show Full Task Title</h3>

  <p align="center">
    <a href="https://chrome.google.com/webstore/detail/teamwork-show-full-task-title">Chrome Web Store</a>
    ·
    <a href="https://github.com/tedbrakob/teamwork-show-full-task-title">Github</a>
  </p>
</div>

<br>

Expands the title of Teamwork tasks to show on multiple lines of text rather than ending with an ellipsis

<br>

---

<br>